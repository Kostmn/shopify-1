import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import ProductDetail from "@/components/ProductDetail";
import FeaturedProducts from "@/components/FeaturedProducts";
import Footer from "@/components/Footer";
import NewsletterSignup from "@/components/NewsletterSignup";

// Sample products data (this would come from an API in a real app)
const allProducts = [
  {
    id: 1,
    name: "Wireless Noise-Canceling Headphones",
    price: 249.99,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Premium wireless headphones with active noise cancellation for immersive sound experience. Features 30-hour battery life, comfortable over-ear design, and superior sound quality for music, movies, and calls.",
    category: "Electronics",
  },
  {
    id: 2,
    name: "Minimalist Analog Watch",
    price: 129.99,
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Elegant and minimalist analog watch with genuine leather strap. Features Japanese quartz movement, scratch-resistant mineral glass, and water resistance up to 30 meters.",
    category: "Accessories",
  },
  {
    id: 3,
    name: "Organic Cotton T-Shirt",
    price: 34.99,
    image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Soft and comfortable t-shirt made from 100% organic cotton. Pre-shrunk fabric, relaxed fit, and available in multiple colors. Ethically sourced and environmentally friendly.",
    category: "Clothing",
  },
  {
    id: 4,
    name: "Smart Home Speaker",
    price: 199.99,
    image: "https://images.unsplash.com/photo-1558089687-f282ff2e1d3f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Smart home speaker with voice control and premium sound quality. Features multi-room audio capability, voice assistant integration, and sleek design that fits any home decor.",
    category: "Electronics",
  },
  {
    id: 5,
    name: "Eco-Friendly Water Bottle",
    price: 24.99,
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Insulated stainless steel water bottle that keeps drinks cold for up to 24 hours or hot for up to 12 hours. BPA-free, leak-proof lid, and available in multiple colors and sizes.",
    category: "Accessories",
  },
  {
    id: 6,
    name: "Wireless Charging Pad",
    price: 39.99,
    image: "https://images.unsplash.com/photo-1574944985070-8f3ebc6b79d2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Fast wireless charging pad compatible with all Qi-enabled devices. Features LED indicator, anti-slip surface, and compact design. Supports fast charging up to 15W.",
    category: "Electronics",
  },
  {
    id: 7,
    name: "Leather Laptop Sleeve",
    price: 59.99,
    image: "https://images.unsplash.com/photo-1603486002664-a7319ea41bc9?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Premium leather laptop sleeve with soft microfiber lining. Fits laptops up to 15 inches, features magnetic closure, and includes an extra pocket for accessories.",
    category: "Accessories",
  },
  {
    id: 8,
    name: "Fitness Tracker Watch",
    price: 89.99,
    image: "https://images.unsplash.com/photo-1557935728-e6d1eae9a562?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Advanced fitness tracker with heart rate monitoring and GPS. Features sleep tracking, water resistance, and 7-day battery life. Compatible with iOS and Android devices.",
    category: "Electronics",
  },
];

const ProductView: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const productId = parseInt(id || "0");
  const product = allProducts.find(p => p.id === productId);
  
  if (!product) {
    // If product not found, redirect to products page
    navigate("/products");
    return null;
  }
  
  // Get related products (same category, excluding current product)
  const relatedProducts = allProducts
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        <ProductDetail product={product} />
        
        {/* Related Products Section */}
        {relatedProducts.length > 0 && (
          <section className="py-12 bg-gray-50">
            <FeaturedProducts 
              title="You May Also Like" 
              products={relatedProducts}
            />
          </section>
        )}
        
        <NewsletterSignup />
      </main>
      
      <Footer />
    </div>
  );
};

export default ProductView;
