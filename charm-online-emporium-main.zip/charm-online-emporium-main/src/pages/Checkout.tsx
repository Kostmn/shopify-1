
import React from "react";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { useCart } from "@/context/CartContext";
import { CreditCard, Package } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

const Checkout: React.FC = () => {
  const { items, subtotal, clearCart } = useCart();
  const navigate = useNavigate();
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real application, this is where you'd handle payment processing
    toast.success("Order placed successfully!");
    clearCart();
    navigate("/");
  };

  if (items.length === 0) {
    navigate("/products");
    return null;
  }
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-shop-dark">Checkout</h1>
          <p className="text-shop-secondary mt-2">Complete your order</p>
        </div>
        
        <form onSubmit={handleSubmit} className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-10">
            {/* Customer Information */}
            <div>
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <span className="flex items-center justify-center bg-shop-primary text-white rounded-full w-6 h-6 mr-2 text-sm">1</span>
                Customer Information
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name</Label>
                  <Input id="firstName" required className="mt-1" />
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input id="lastName" required className="mt-1" />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" required className="mt-1" />
                </div>
                <div>
                  <Label htmlFor="phone">Phone</Label>
                  <Input id="phone" type="tel" className="mt-1" />
                </div>
              </div>
            </div>
            
            {/* Shipping Address */}
            <div>
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <span className="flex items-center justify-center bg-shop-primary text-white rounded-full w-6 h-6 mr-2 text-sm">2</span>
                Shipping Address
              </h2>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="address">Street Address</Label>
                  <Input id="address" required className="mt-1" />
                </div>
                <div>
                  <Label htmlFor="apartment">Apartment, suite, etc. (optional)</Label>
                  <Input id="apartment" className="mt-1" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="city">City</Label>
                    <Input id="city" required className="mt-1" />
                  </div>
                  <div>
                    <Label htmlFor="state">State/Province</Label>
                    <Input id="state" required className="mt-1" />
                  </div>
                  <div>
                    <Label htmlFor="zipCode">ZIP / Postal Code</Label>
                    <Input id="zipCode" required className="mt-1" />
                  </div>
                </div>
              </div>
            </div>
            
            {/* Shipping Method */}
            <div>
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <span className="flex items-center justify-center bg-shop-primary text-white rounded-full w-6 h-6 mr-2 text-sm">3</span>
                Shipping Method
              </h2>
              <RadioGroup defaultValue="standard">
                <div className="flex items-center space-x-2 border rounded-md p-4">
                  <RadioGroupItem value="standard" id="standard" />
                  <Label htmlFor="standard" className="flex-1 cursor-pointer">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <Package className="mr-2 h-4 w-4 text-shop-secondary" />
                        <span>Standard Shipping (3-5 business days)</span>
                      </div>
                      <span>Free</span>
                    </div>
                  </Label>
                </div>
                <div className="flex items-center space-x-2 border rounded-md p-4 mt-2">
                  <RadioGroupItem value="express" id="express" />
                  <Label htmlFor="express" className="flex-1 cursor-pointer">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <Package className="mr-2 h-4 w-4 text-shop-secondary" />
                        <span>Express Shipping (1-2 business days)</span>
                      </div>
                      <span>$9.99</span>
                    </div>
                  </Label>
                </div>
              </RadioGroup>
            </div>
            
            {/* Payment Information */}
            <div>
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <span className="flex items-center justify-center bg-shop-primary text-white rounded-full w-6 h-6 mr-2 text-sm">4</span>
                Payment Method
              </h2>
              <div className="border rounded-md p-6 space-y-4">
                <div className="flex items-center space-x-2">
                  <CreditCard className="h-5 w-5 text-shop-secondary" />
                  <span className="font-medium">Credit Card</span>
                </div>
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <Label htmlFor="cardNumber">Card Number</Label>
                    <Input id="cardNumber" placeholder="0000 0000 0000 0000" required className="mt-1" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="expiration">Expiration (MM/YY)</Label>
                      <Input id="expiration" placeholder="MM/YY" required className="mt-1" />
                    </div>
                    <div>
                      <Label htmlFor="cvc">CVC</Label>
                      <Input id="cvc" placeholder="CVC" required className="mt-1" />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="nameOnCard">Name on Card</Label>
                    <Input id="nameOnCard" required className="mt-1" />
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Order Summary */}
          <div className="md:col-span-1">
            <div className="bg-gray-50 rounded-lg p-6 sticky top-24">
              <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
              
              <div className="space-y-4 mb-4">
                {items.map((item) => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <span className="flex-1">
                      {item.name} <span className="text-shop-secondary">×{item.quantity}</span>
                    </span>
                    <span className="font-medium">${(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>
              
              <Separator className="my-4" />
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span className="font-medium">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Shipping:</span>
                  <span>Free</span>
                </div>
                <div className="flex justify-between">
                  <span>Tax:</span>
                  <span>${(subtotal * 0.08).toFixed(2)}</span>
                </div>
              </div>
              
              <Separator className="my-4" />
              
              <div className="flex justify-between text-lg font-bold">
                <span>Total:</span>
                <span>${(subtotal + subtotal * 0.08).toFixed(2)}</span>
              </div>
              
              <Button type="submit" className="w-full mt-6 bg-shop-accent hover:bg-shop-accent/90">
                Place Order
              </Button>
              
              <p className="text-xs text-center text-shop-secondary mt-4">
                By placing your order, you agree to our Terms of Service and Privacy Policy
              </p>
            </div>
          </div>
        </form>
      </main>
      
      {/* Footer (simplified version) */}
      <footer className="bg-shop-dark text-white mt-auto">
        <div className="container mx-auto px-4 py-8">
          <div className="border-t border-gray-700 pt-4 text-center text-gray-300">
            <p>&copy; {new Date().getFullYear()} ShopEase. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Checkout;
