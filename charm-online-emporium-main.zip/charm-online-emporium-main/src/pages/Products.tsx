import React from "react";
import Navbar from "@/components/Navbar";
import ProductGrid from "@/components/ProductGrid";
import { useSearchParams } from "react-router-dom";
import Footer from "@/components/Footer";
import NewsletterSignup from "@/components/NewsletterSignup";

// Sample products data (in a real app, this would come from an API)
const allProducts = [
  {
    id: 1,
    name: "Wireless Noise-Canceling Headphones",
    price: 249.99,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Premium wireless headphones with active noise cancellation for immersive sound experience.",
    category: "Electronics",
  },
  {
    id: 2,
    name: "Minimalist Analog Watch",
    price: 129.99,
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Elegant and minimalist analog watch with genuine leather strap.",
    category: "Accessories",
  },
  {
    id: 3,
    name: "Organic Cotton T-Shirt",
    price: 34.99,
    image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Soft and comfortable t-shirt made from 100% organic cotton.",
    category: "Clothing",
  },
  {
    id: 4,
    name: "Smart Home Speaker",
    price: 199.99,
    image: "https://images.unsplash.com/photo-1558089687-f282ff2e1d3f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Smart home speaker with voice control and premium sound quality.",
    category: "Electronics",
  },
  {
    id: 5,
    name: "Eco-Friendly Water Bottle",
    price: 24.99,
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Insulated stainless steel water bottle that keeps drinks cold for up to 24 hours.",
    category: "Accessories",
  },
  {
    id: 6,
    name: "Wireless Charging Pad",
    price: 39.99,
    image: "https://images.unsplash.com/photo-1574944985070-8f3ebc6b79d2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Fast wireless charging pad compatible with all Qi-enabled devices.",
    category: "Electronics",
  },
  {
    id: 7,
    name: "Leather Laptop Sleeve",
    price: 59.99,
    image: "https://images.unsplash.com/photo-1603486002664-a7319ea41bc9?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Premium leather laptop sleeve with soft microfiber lining.",
    category: "Accessories",
  },
  {
    id: 8,
    name: "Fitness Tracker Watch",
    price: 89.99,
    image: "https://images.unsplash.com/photo-1557935728-e6d1eae9a562?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Advanced fitness tracker with heart rate monitoring and GPS.",
    category: "Electronics",
  },
  {
    id: 9,
    name: "Bamboo Cutting Board",
    price: 29.99,
    image: "https://images.unsplash.com/photo-1589986005992-5de19e3d9e70?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Eco-friendly bamboo cutting board, durable and knife-friendly.",
    category: "Home & Kitchen",
  },
  {
    id: 10,
    name: "Ceramic Coffee Mug",
    price: 14.99,
    image: "https://images.unsplash.com/photo-1577937927133-33b083cca3fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Handcrafted ceramic coffee mug with modern design.",
    category: "Home & Kitchen",
  },
  {
    id: 11,
    name: "Wool Blend Sweater",
    price: 79.99,
    image: "https://images.unsplash.com/photo-1603252109303-2751441dd157?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Warm and comfortable wool blend sweater for cold weather.",
    category: "Clothing",
  },
  {
    id: 12,
    name: "Bluetooth Earbuds",
    price: 119.99,
    image: "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "True wireless Bluetooth earbuds with long battery life.",
    category: "Electronics",
  },
];

const categories = ["Electronics", "Clothing", "Accessories", "Home & Kitchen"];

const Products: React.FC = () => {
  const [searchParams] = useSearchParams();
  const categoryParam = searchParams.get("category");
  
  // Filter products if category is specified in URL
  const products = categoryParam
    ? allProducts.filter(product => product.category === categoryParam)
    : allProducts;
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-shop-dark">
            {categoryParam ? `${categoryParam}` : "All Products"}
          </h1>
          <p className="text-shop-secondary mt-2">
            {categoryParam 
              ? `Browse our ${categoryParam.toLowerCase()} collection`
              : "Browse our entire catalog of quality products"}
          </p>
        </div>
        
        <ProductGrid products={products} categories={categories} />
      </main>
      
      <NewsletterSignup />
      <Footer />
    </div>
  );
};

export default Products;
