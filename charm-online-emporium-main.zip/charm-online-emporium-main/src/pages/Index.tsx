
import React from "react";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import FeaturedProducts from "@/components/FeaturedProducts";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import PromotionBanner from "@/components/PromotionBanner";
import Testimonials from "@/components/Testimonials";
import BrandShowcase from "@/components/BrandShowcase";
import NewsletterSignup from "@/components/NewsletterSignup";

// Sample data for featured products
const featuredProducts = [
  {
    id: 1,
    name: "Wireless Noise-Canceling Headphones",
    price: 249.99,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Premium wireless headphones with active noise cancellation for immersive sound experience.",
    category: "Electronics",
  },
  {
    id: 2,
    name: "Minimalist Analog Watch",
    price: 129.99,
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Elegant and minimalist analog watch with genuine leather strap.",
    category: "Accessories",
  },
  {
    id: 3,
    name: "Organic Cotton T-Shirt",
    price: 34.99,
    image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Soft and comfortable t-shirt made from 100% organic cotton.",
    category: "Clothing",
  },
  {
    id: 4,
    name: "Smart Home Speaker",
    price: 199.99,
    image: "https://images.unsplash.com/photo-1558089687-f282ff2e1d3f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Smart home speaker with voice control and premium sound quality.",
    category: "Electronics",
  },
];

const newArrivalsProducts = [
  {
    id: 5,
    name: "Eco-Friendly Water Bottle",
    price: 24.99,
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Insulated stainless steel water bottle that keeps drinks cold for up to 24 hours.",
    category: "Accessories",
  },
  {
    id: 6,
    name: "Wireless Charging Pad",
    price: 39.99,
    image: "https://images.unsplash.com/photo-1574944985070-8f3ebc6b79d2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Fast wireless charging pad compatible with all Qi-enabled devices.",
    category: "Electronics",
  },
  {
    id: 7,
    name: "Leather Laptop Sleeve",
    price: 59.99,
    image: "https://images.unsplash.com/photo-1603486002664-a7319ea41bc9?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Premium leather laptop sleeve with soft microfiber lining.",
    category: "Accessories",
  },
  {
    id: 8,
    name: "Fitness Tracker Watch",
    price: 89.99,
    image: "https://images.unsplash.com/photo-1557935728-e6d1eae9a562?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    description: "Advanced fitness tracker with heart rate monitoring and GPS.",
    category: "Electronics",
  },
];

const Index: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <Hero />

      {/* Promotion Banner */}
      <PromotionBanner 
        title="Summer Sale is LIVE!" 
        description="Up to 50% off on selected items. Use code:"
        code="SUMMER50"
        link="/products"
        buttonText="Shop the Sale"
        bgColor="bg-rose-50"
        textColor="text-rose-700"
      />

      <main>
        <FeaturedProducts 
          title="Featured Products" 
          subtitle="Our most popular products"
          products={featuredProducts}
          viewAllLink="/products"
        />

        {/* Categories Section */}
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-bold text-shop-dark mb-8">Shop by Category</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {["Electronics", "Clothing", "Accessories", "Home & Kitchen"].map((category) => (
                <Link 
                  key={category} 
                  to={`/products?category=${category}`} 
                  className="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow text-center"
                >
                  <div className="mb-4 h-16 flex items-center justify-center">
                    <div className="w-16 h-16 rounded-full bg-shop-accent/10 flex items-center justify-center">
                      <span className="text-2xl text-shop-accent">
                        {category === "Electronics" && "🎧"}
                        {category === "Clothing" && "👕"}
                        {category === "Accessories" && "⌚"}
                        {category === "Home & Kitchen" && "🏠"}
                      </span>
                    </div>
                  </div>
                  <h3 className="font-medium text-lg text-shop-primary">{category}</h3>
                  <p className="text-shop-secondary text-sm mt-2">Shop all {category.toLowerCase()}</p>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <Testimonials />

        <FeaturedProducts 
          title="New Arrivals" 
          subtitle="The latest additions to our catalog"
          products={newArrivalsProducts}
        />

        {/* Brand Showcase */}
        <BrandShowcase />

        {/* Newsletter Signup */}
        <NewsletterSignup />

        {/* Special Promotion Section */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="bg-shop-accent/10 rounded-lg overflow-hidden">
              <div className="grid md:grid-cols-2">
                <div className="p-8 md:p-12 flex flex-col justify-center">
                  <div className="inline-block bg-shop-accent text-white text-sm px-3 py-1 rounded-full mb-4">
                    Limited Time Offer
                  </div>
                  <h2 className="text-2xl md:text-3xl font-bold text-shop-dark mb-4">
                    Get 20% Off Your First Purchase
                  </h2>
                  <p className="text-shop-secondary mb-6">
                    Use code WELCOME20 at checkout to receive 20% off your first order.
                  </p>
                  <Button asChild className="inline-flex items-center w-fit">
                    <Link to="/products">
                      Shop Now 
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
                <div className="hidden md:block">
                  <img
                    src="https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                    alt="Special Offer"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-shop-dark text-white mt-auto">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div>
              <h3 className="font-bold text-lg mb-4">ShopEase</h3>
              <p className="text-gray-300 mb-4">
                Your one-stop shop for all your needs. Quality products at competitive prices.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-300 hover:text-white">
                  Facebook
                </a>
                <a href="#" className="text-gray-300 hover:text-white">
                  Twitter
                </a>
                <a href="#" className="text-gray-300 hover:text-white">
                  Instagram
                </a>
              </div>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">Shop</h3>
              <ul className="space-y-2">
                <li><Link to="/products" className="text-gray-300 hover:text-white">All Products</Link></li>
                <li><Link to="/products?category=Electronics" className="text-gray-300 hover:text-white">Electronics</Link></li>
                <li><Link to="/products?category=Clothing" className="text-gray-300 hover:text-white">Clothing</Link></li>
                <li><Link to="/products?category=Accessories" className="text-gray-300 hover:text-white">Accessories</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">Customer Service</h3>
              <ul className="space-y-2">
                <li><Link to="/contact" className="text-gray-300 hover:text-white">Contact Us</Link></li>
                <li><Link to="/shipping" className="text-gray-300 hover:text-white">Shipping Info</Link></li>
                <li><Link to="/returns" className="text-gray-300 hover:text-white">Returns & Exchanges</Link></li>
                <li><Link to="/faq" className="text-gray-300 hover:text-white">FAQ</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">About Us</h3>
              <ul className="space-y-2">
                <li><Link to="/about" className="text-gray-300 hover:text-white">Our Story</Link></li>
                <li><Link to="/careers" className="text-gray-300 hover:text-white">Careers</Link></li>
                <li><Link to="/privacy" className="text-gray-300 hover:text-white">Privacy Policy</Link></li>
                <li><Link to="/terms" className="text-gray-300 hover:text-white">Terms of Service</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-300">
            <p>&copy; {new Date().getFullYear()} ShopEase. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
