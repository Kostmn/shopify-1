
import React from "react";
import Navbar from "@/components/Navbar";
import Cart from "@/components/Cart";
import Footer from "@/components/Footer";
import PromotionBanner from "@/components/PromotionBanner";

const CartPage: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />
      
      <PromotionBanner 
        title="Free Shipping on Orders Over £50" 
        description="UK mainland only"
        link="/products"
        buttonText="Shop Now"
        bgColor="bg-icomi-red/10"
        textColor="text-icomi-red"
      />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6 text-center md:text-left">Your Cart</h1>
        <Cart />
      </main>
      
      <Footer />
    </div>
  );
};

export default CartPage;
