
import React from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

const Hero: React.FC = () => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-blue-50 to-white">
      <div className="container mx-auto px-4 py-16 md:py-24">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="space-y-6 md:pr-8">
            <span className="inline-block bg-blue-100 text-shop-accent px-4 py-2 rounded-full text-sm font-medium">
              Summer Collection 2025
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-shop-primary leading-tight">
              Discover the Latest Trends in Fashion
            </h1>
            <p className="text-xl text-shop-secondary">
              Shop our curated collection of premium products at unbeatable prices. Free shipping on orders over $50.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button asChild size="lg" className="bg-shop-accent hover:bg-shop-accent/90">
                <Link to="/products">
                  Shop Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/products?category=New+Arrivals">
                  New Arrivals
                </Link>
              </Button>
            </div>
          </div>
          <div className="hidden md:block relative">
            <div className="absolute top-0 right-0 w-72 h-72 bg-yellow-200 rounded-full -translate-y-1/4 translate-x-1/4 opacity-20"></div>
            <div className="absolute bottom-0 left-0 w-60 h-60 bg-blue-200 rounded-full translate-y-1/4 -translate-x-1/4 opacity-20"></div>
            <div className="relative z-10 p-4">
              <img
                src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
                alt="Shopping Experience"
                className="rounded-lg shadow-2xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-lg shadow-lg">
                <div className="flex items-center gap-2">
                  <div className="bg-green-100 text-green-700 p-2 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <div>
                    <p className="font-medium text-shop-primary">Trusted Shop</p>
                    <p className="text-xs text-shop-secondary">Over 10,000 happy customers</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white to-transparent"></div>
    </section>
  );
};

export default Hero;
