
import React from "react";

const brands = [
  { name: "Brand One", logo: "https://via.placeholder.com/150x80?text=Brand+1" },
  { name: "Brand Two", logo: "https://via.placeholder.com/150x80?text=Brand+2" },
  { name: "Brand Three", logo: "https://via.placeholder.com/150x80?text=Brand+3" },
  { name: "Brand Four", logo: "https://via.placeholder.com/150x80?text=Brand+4" },
  { name: "Brand Five", logo: "https://via.placeholder.com/150x80?text=Brand+5" },
  { name: "Brand Six", logo: "https://via.placeholder.com/150x80?text=Brand+6" },
];

const BrandShowcase: React.FC = () => {
  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold text-center text-shop-dark mb-8">Our Trusted Brands</h2>
        
        <div className="flex flex-wrap justify-center items-center gap-8 md:gap-12">
          {brands.map((brand, index) => (
            <div key={index} className="grayscale hover:grayscale-0 transition-all duration-300">
              <img 
                src={brand.logo} 
                alt={brand.name} 
                className="max-h-12 max-w-[120px] md:max-w-[150px]"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BrandShowcase;
