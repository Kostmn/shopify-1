
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { ShoppingCart, Heart, Share2, Star, Truck, Shield, RotateCcw } from "lucide-react";
import { type Product, useCart } from "@/context/CartContext";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";

interface ProductDetailProps {
  product: Product;
}

const ProductDetail: React.FC<ProductDetailProps> = ({ product }) => {
  const [quantity, setQuantity] = useState(1);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const { addItem } = useCart();

  const handleQuantityChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setQuantity(Number(e.target.value));
  };

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addItem(product);
    }
  };

  const handleWishlist = () => {
    setIsWishlisted(!isWishlisted);
    if (!isWishlisted) {
      toast.success(`${product.name} added to your wishlist`);
    } else {
      toast.info(`${product.name} removed from your wishlist`);
    }
  };

  const handleShare = () => {
    toast.info('Share functionality coming soon');
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid md:grid-cols-2 gap-8">
        {/* Product Image Gallery */}
        <div className="space-y-4">
          <div className="bg-gray-50 rounded-lg overflow-hidden aspect-square">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-contain object-center p-4"
            />
          </div>
          <div className="grid grid-cols-4 gap-2">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="bg-gray-50 rounded-lg aspect-square cursor-pointer hover:border-2 hover:border-shop-accent">
                <img
                  src={product.image}
                  alt={`${product.name} view ${i}`}
                  className="w-full h-full object-contain object-center p-2"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Product Details */}
        <div className="space-y-6">
          <div>
            <p className="text-shop-accent">{product.category}</p>
            <h1 className="text-3xl font-bold text-shop-primary mt-1">{product.name}</h1>
            <div className="flex items-center mt-2">
              <div className="flex items-center text-yellow-500">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
              </div>
              <span className="ml-2 text-shop-secondary text-sm">4.9 (120 reviews)</span>
            </div>
          </div>

          <div className="text-3xl font-bold">${product.price.toFixed(2)}</div>

          <Separator />

          <div className="space-y-4">
            <p className="text-shop-secondary">{product.description}</p>
            <p className="text-sm bg-green-50 text-green-600 px-3 py-1 inline-block rounded">In stock and ready to ship</p>
          </div>

          <div className="flex items-center gap-4 pt-4">
            <select
              value={quantity}
              onChange={handleQuantityChange}
              className="rounded border border-gray-300 p-2 w-20"
              aria-label="Select quantity"
            >
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                <option key={num} value={num}>
                  {num}
                </option>
              ))}
            </select>
            
            <Button 
              onClick={handleAddToCart} 
              size="lg"
              className="flex-1 bg-shop-accent hover:bg-shop-accent/90"
            >
              <ShoppingCart className="mr-2 h-5 w-5" />
              Add to Cart
            </Button>
          </div>
          
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleWishlist}
              className={isWishlisted ? "text-red-500" : ""}
            >
              <Heart className={`mr-1 h-4 w-4 ${isWishlisted ? "fill-current" : ""}`} />
              Wishlist
            </Button>
            <Button variant="outline" size="sm" onClick={handleShare}>
              <Share2 className="mr-1 h-4 w-4" />
              Share
            </Button>
          </div>
          
          <Separator />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 py-4">
            <div className="flex items-center gap-2">
              <Truck className="text-shop-accent h-5 w-5" />
              <div>
                <p className="font-medium text-sm">Free Shipping</p>
                <p className="text-xs text-shop-secondary">Orders over $50</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Shield className="text-shop-accent h-5 w-5" />
              <div>
                <p className="font-medium text-sm">Secure Payment</p>
                <p className="text-xs text-shop-secondary">100% Protected</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <RotateCcw className="text-shop-accent h-5 w-5" />
              <div>
                <p className="font-medium text-sm">Easy Returns</p>
                <p className="text-xs text-shop-secondary">30 Day Return Policy</p>
              </div>
            </div>
          </div>
          
          <div className="pt-6 space-y-4">
            <h3 className="font-medium">Product Details:</h3>
            <ul className="list-disc pl-5 text-shop-secondary space-y-1">
              <li>Premium quality</li>
              <li>Fast shipping</li>
              <li>30-day return policy</li>
              <li>Satisfaction guaranteed</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
