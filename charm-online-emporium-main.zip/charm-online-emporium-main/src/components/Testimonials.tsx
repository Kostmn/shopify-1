
import React from "react";
import { Card, CardContent } from "@/components/ui/card";

interface TestimonialProps {
  quote: string;
  author: string;
  role: string;
  avatar?: string;
}

const testimonials: TestimonialProps[] = [
  {
    quote: "I'm absolutely in love with the quality of the products. Fast shipping and amazing customer service!",
    author: "Sarah Johnson",
    role: "Loyal Customer",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=4&w=256&h=256&q=60",
  },
  {
    quote: "The best online shopping experience I've had in years. The user interface is intuitive and checkout process is smooth.",
    author: "Michael Rodriguez",
    role: "Verified Buyer",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=4&w=256&h=256&q=60",
  },
  {
    quote: "Their customer support is exceptional. They went above and beyond to help me with my order.",
    author: "Emma Thompson",
    role: "New Customer",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=4&w=256&h=256&q=60",
  },
];

const Testimonials: React.FC = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-shop-dark">What Our Customers Say</h2>
          <p className="mt-4 text-shop-secondary max-w-2xl mx-auto">
            Don't just take our word for it — see what our satisfied customers have to say about their shopping experience.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-white border-none shadow-md">
              <CardContent className="pt-6">
                <div className="flex flex-col h-full">
                  <div className="mb-4 text-yellow-500 flex">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 fill-current" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                  
                  <p className="text-shop-secondary italic flex-grow">"{testimonial.quote}"</p>
                  
                  <div className="flex items-center mt-6">
                    {testimonial.avatar && (
                      <div className="mr-3">
                        <img 
                          src={testimonial.avatar} 
                          alt={testimonial.author}
                          className="w-10 h-10 rounded-full object-cover" 
                        />
                      </div>
                    )}
                    <div>
                      <p className="font-medium text-shop-primary">{testimonial.author}</p>
                      <p className="text-sm text-shop-secondary">{testimonial.role}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
