
import React from "react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

interface PromotionBannerProps {
  title: string;
  description: string;
  code?: string;
  link: string;
  buttonText: string;
  bgColor?: string;
  textColor?: string;
}

const PromotionBanner: React.FC<PromotionBannerProps> = ({
  title,
  description,
  code,
  link,
  buttonText,
  bgColor = "bg-icomi-red/10",
  textColor = "text-icomi-red",
}) => {
  return (
    <section className={`py-3 ${bgColor} ${textColor}`}>
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-center md:text-left">
            <h3 className="text-lg md:text-xl font-bold">{title}</h3>
            <p className="mt-1 text-sm">{description}</p>
            {code && (
              <div className="mt-2">
                <span className="inline-block bg-white px-3 py-1 rounded-md font-mono font-medium">
                  {code}
                </span>
              </div>
            )}
          </div>
          <Button asChild variant="outline" className="border-icomi-red hover:bg-icomi-red hover:text-white">
            <Link to={link}>{buttonText}</Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default PromotionBanner;
