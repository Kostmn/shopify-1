
import React from "react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/context/CartContext";
import { Link } from "react-router-dom";
import { Minus, Plus, Trash2 } from "lucide-react";
import { Separator } from "@/components/ui/separator";

const Cart: React.FC = () => {
  const { items, removeItem, updateQuantity, clearCart, subtotal } = useCart();

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16">
        <h2 className="text-2xl font-bold mb-4">Your cart is empty</h2>
        <p className="text-shop-secondary mb-8">Add some products to your cart to see them here.</p>
        <Button asChild>
          <Link to="/products">Continue Shopping</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <h1 className="text-2xl md:text-3xl font-bold">Shopping Cart</h1>
      
      <div className="space-y-4">
        <div className="hidden md:grid grid-cols-6 font-medium text-shop-secondary py-2 border-b">
          <div className="col-span-3">Product</div>
          <div className="text-center">Price</div>
          <div className="text-center">Quantity</div>
          <div className="text-right">Total</div>
        </div>
        
        {items.map((item) => (
          <div key={item.id} className="grid grid-cols-1 md:grid-cols-6 gap-4 py-4 border-b items-center">
            <div className="md:col-span-3 flex items-center gap-4">
              <div className="w-20 h-20 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <h3 className="font-medium">
                  <Link to={`/product/${item.id}`} className="hover:text-shop-accent">
                    {item.name}
                  </Link>
                </h3>
                <p className="text-sm text-shop-secondary">{item.category}</p>
                <button
                  onClick={() => removeItem(item.id)}
                  className="flex items-center text-sm text-red-500 md:hidden mt-2"
                >
                  <Trash2 className="h-4 w-4 mr-1" />
                  Remove
                </button>
              </div>
            </div>
            
            <div className="md:text-center flex justify-between md:block">
              <span className="md:hidden">Price:</span>
              <span>${item.price.toFixed(2)}</span>
            </div>
            
            <div className="md:text-center">
              <div className="flex items-center justify-between md:justify-center gap-2">
                <span className="md:hidden">Quantity:</span>
                <div className="flex items-center border rounded-md">
                  <button
                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                    className="px-3 py-1 text-gray-500 hover:text-shop-primary"
                    aria-label="Decrease quantity"
                  >
                    <Minus className="h-3 w-3" />
                  </button>
                  <span className="px-3 py-1">{item.quantity}</span>
                  <button
                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                    className="px-3 py-1 text-gray-500 hover:text-shop-primary"
                    aria-label="Increase quantity"
                  >
                    <Plus className="h-3 w-3" />
                  </button>
                </div>
              </div>
            </div>
            
            <div className="md:text-right flex justify-between md:block">
              <span className="md:hidden">Total:</span>
              <div className="flex items-center justify-end gap-4">
                <span className="font-medium">${(item.price * item.quantity).toFixed(2)}</span>
                <button
                  onClick={() => removeItem(item.id)}
                  className="text-red-500 hidden md:block"
                  aria-label="Remove item"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="flex flex-col md:flex-row md:justify-between gap-4 items-start">
        <Button 
          variant="outline" 
          onClick={clearCart}
          className="text-sm"
        >
          Clear Cart
        </Button>
        
        <div className="w-full md:w-72 p-6 bg-gray-50 rounded-lg space-y-4">
          <h3 className="font-bold text-lg">Order Summary</h3>
          
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-shop-secondary">Subtotal:</span>
              <span className="font-medium">${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-shop-secondary">Shipping:</span>
              <span>Calculated at checkout</span>
            </div>
          </div>
          
          <Separator />
          
          <div className="flex justify-between font-bold">
            <span>Estimated Total:</span>
            <span>${subtotal.toFixed(2)}</span>
          </div>
          
          <Button asChild className="w-full bg-shop-accent hover:bg-shop-accent/90">
            <Link to="/checkout">Proceed to Checkout</Link>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Cart;
